<?php
/* Smarty version 3.1.33, created on 2019-02-18 12:31:04
  from '/home/mishusoft/public_html/project/tcms/default/modules/core/views/pages/appmanager/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c6a512828bf05_62303300',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd91a9d01c56b41354b42fa43d7b97d58a66b1730' => 
    array (
      0 => '/home/mishusoft/public_html/project/tcms/default/modules/core/views/pages/appmanager/index.tpl',
      1 => 1550383291,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c6a512828bf05_62303300 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <fieldset class="box-shadow-light">
            <legend class="box-shadow-light"> App Manager</legend>
            <div class="row" id="adminMenus">
                <div class="thumbnail box-shadow-light">
                    <div class="thumbnail-image"><i class="fas fa-wrench"></i></div>
                    <div class="thumbnail-text">Loading..</div>
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php }
}
