<?php
/* Smarty version 3.1.33, created on 2019-02-19 21:01:17
  from '/home/mishusoft/public_html/project/tcms/default/modules/core/views/pages/products/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5c6c1a3d678143_78109912',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6df1b5fa0e098f7d788d320d112a482269804bf8' => 
    array (
      0 => '/home/mishusoft/public_html/project/tcms/default/modules/core/views/pages/products/index.tpl',
      1 => 1550383313,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c6c1a3d678143_78109912 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row">
    <fieldset class="box-shadow-light">
        <legend class="box-shadow-light"> Products</legend>
        <div class="row" id="products">
            <div class="quick-access-app box-shadow-light">
                <div class="quick-access-app-logo">
                    <span class="quick-access-app-logo-image-alt"><i class="fab fa-app-store"></i></span>
                </div>
                <div class="quick-access-app-text">
                    <div class="quick-access-app-title-text">Loading...</div>
                    <div class="quick-access-app-status-text">&nbsp;</div>
                </div>
            </div>
        </div>
    </fieldset>
</div><?php }
}
