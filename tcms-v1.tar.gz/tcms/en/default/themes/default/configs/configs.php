<?php

function get_layout_positions(){

    return array(
        'header' => array(),
        'left' => array(),
        'right' => array(),
        'footer' => array()
    );
}